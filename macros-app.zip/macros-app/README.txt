MACROS - setup (about 10 minutes, free)

Files: index.html, sw.js, manifest.webmanifest, html5-qrcode.min.js,
icon-192.png, icon-512.png, apple-touch-icon.png. Upload ALL of them.

1. Unzip: in the Files app, tap macros-app.zip. A "macros-app" folder appears.
2. Make a free account at github.com (in Safari).
3. Tap "+" > New repository. Name it "macros", choose Public, tick
   "Add a README file", tap Create repository.
4. In the new repo: Add file > Upload files. (If you don't see it, tap
   the aA button in Safari's address bar > Request Desktop Website.)
   Choose the 7 files from the macros-app folder, then Commit changes.
5. Settings > Pages. Under "Build and deployment", Source = Deploy from
   a branch, Branch = main, folder = / (root). Save.
6. Wait 1-2 minutes. Your app is at https://YOUR-USERNAME.github.io/macros/
7. Open that link in Safari > Share > Add to Home Screen > Add.

Open it from the new pink icon: full screen, no browser bars, works offline.
The first time you tap Scan, allow camera access.

Your data stays on your phone (not on GitHub). Tap "Back up" now and then
and save the file to iCloud Drive; "Restore" brings it back on a new phone.

Updating later: upload the changed files to the repo, and change
VERSION in sw.js (e.g. macros-v2) so your phone picks up the new version.
